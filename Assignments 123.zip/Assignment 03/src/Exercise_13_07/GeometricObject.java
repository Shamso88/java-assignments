package Exercise_13_07;

public abstract class GeometricObject {
    public abstract double getArea();
}

