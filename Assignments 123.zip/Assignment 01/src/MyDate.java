public class MyDate {
    String date;

    public MyDate(String date) {
        this.date = date;
    }
}
